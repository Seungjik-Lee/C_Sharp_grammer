﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hello
{
    public class Student
    {

    }

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MessageBox.Show("Hello");
        }
    }
}


//namespace Hello2
//{
//    public class Student
//    {

//    }

//    public partial class Form1 : Form
//    {
//        public Form1()
//        {
//            MessageBox.Show("Hello");
//        }
//    }
//}
